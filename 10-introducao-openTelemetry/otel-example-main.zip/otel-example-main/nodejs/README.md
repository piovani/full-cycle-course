# OpenTelemetry Project

to start this app run

`docker run -d -p 9411:9411 openzipkin/zipkin`
to start a zipkin container

#`npm i`
to install the packages

#`node courses.js`
in one tab

#`node dashboard.js`
in another tab

then visit localhost:3001/dashboard

Now view the tracing data in zipkin : http://localhost:9411/zipkin/
