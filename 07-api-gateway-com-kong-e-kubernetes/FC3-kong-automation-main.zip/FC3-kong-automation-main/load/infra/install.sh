#!/bin/bash
kubectl testkube install
