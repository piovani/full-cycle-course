#!/bin/bash
kubectl apply -f pod.yaml
