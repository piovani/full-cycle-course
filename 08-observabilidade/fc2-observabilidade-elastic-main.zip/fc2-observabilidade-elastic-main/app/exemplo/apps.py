from django.apps import AppConfig


class ExemploConfig(AppConfig):
    name = 'exemplo'
